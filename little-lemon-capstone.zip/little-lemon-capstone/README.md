# Little Lemon React Native Capstone

A React Native mobile app built with Expo for the Little Lemon restaurant capstone peer review.

## Features
- First-launch onboarding with first name, last name, email and phone.
- Next button stays disabled until all details are valid.
- Home screen with header, restaurant hero/description, search bar, category filters and menu list.
- Profile screen prefilled from onboarding.
- Profile edits saved locally using AsyncStorage and retained after app restart.
- Logout clears the saved profile and returns to onboarding.
- Stack navigation with a native back button.

## Requirements
- Node.js LTS
- Expo Go on a phone, or an Android/iOS simulator
- Internet connection for installing dependencies

## Run the app
1. Extract this project folder.
2. Open a terminal in the `little-lemon-capstone` folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start Expo:

   ```bash
   npx expo start
   ```

5. Scan the QR code using Expo Go, or press `a` for an Android emulator / `i` for an iOS simulator.

## Test checklist
1. Start with cleared app storage. The onboarding screen should appear.
2. Leave a field empty: Next should be disabled.
3. Enter a first name, last name, valid email and phone number: Next becomes enabled.
4. Tap Next: the Home screen appears.
5. Search for a menu item and select different categories.
6. Tap the profile avatar: profile fields should contain the onboarding details.
7. Change a detail, tap Save changes, then restart the app. The saved detail should remain.
8. Tap Log out and confirm. The app should return to onboarding and the profile should be cleared.
9. Use the navigation back arrow from Profile to return to Home.

## Wireframe
The `assets/little-lemon-wireframe.jpg` file is a submission-ready conceptual wireframe. Include it in your GitHub repository.

## Notes
- This is a learning capstone/demo app. It does not connect to a live restaurant ordering or payment backend.
- Menu items are sample content stored locally in `App.js`.
