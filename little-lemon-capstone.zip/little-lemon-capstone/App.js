import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator, Alert, FlatList, KeyboardAvoidingView, Platform,
  Pressable, ScrollView, StyleSheet, Text, TextInput, View
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';

const Stack = createNativeStackNavigator();
const PROFILE_KEY = '@little_lemon_profile';

const COLORS = {
  green: '#495E57', yellow: '#F4CE14', cream: '#F7F4E9',
  white: '#FFFFFF', dark: '#26332F', muted: '#66736E',
  line: '#E4E8E3', pale: '#EAF0EC'
};

const MENU = [
  { id: '1', name: 'Greek Salad', category: 'Starters', price: '$12.99', description: 'Crisp lettuce, peppers, olives and our house dressing.' },
  { id: '2', name: 'Bruschetta', category: 'Starters', price: '$8.99', description: 'Grilled bread with fresh tomatoes, basil and olive oil.' },
  { id: '3', name: 'Lemon Chicken', category: 'Mains', price: '$18.50', description: 'Tender chicken with herbs and a bright lemon sauce.' },
  { id: '4', name: 'Grilled Fish', category: 'Mains', price: '$21.00', description: 'Fresh fish served with seasonal vegetables.' },
  { id: '5', name: 'Pasta Primavera', category: 'Mains', price: '$16.75', description: 'Pasta tossed with colourful seasonal vegetables.' },
  { id: '6', name: 'Lemon Tart', category: 'Desserts', price: '$7.50', description: 'A smooth, tangy lemon filling in a crisp pastry shell.' },
  { id: '7', name: 'Baklava', category: 'Desserts', price: '$6.50', description: 'Flaky pastry layered with nuts and a little honey.' },
  { id: '8', name: 'Fresh Lemonade', category: 'Drinks', price: '$4.25', description: 'Freshly squeezed lemons, lightly sweetened.' }
];
const CATEGORIES = ['All', 'Starters', 'Mains', 'Desserts', 'Drinks'];

function Field({ label, value, onChangeText, placeholder, keyboardType = 'default' }) {
  return <View style={styles.fieldWrap}>
    <Text style={styles.fieldLabel}>{label}</Text>
    <TextInput
      style={styles.input} value={value} onChangeText={onChangeText}
      placeholder={placeholder} placeholderTextColor="#9AA49F"
      keyboardType={keyboardType} autoCapitalize={keyboardType === 'email-address' ? 'none' : 'words'}
    />
  </View>;
}

function PrimaryButton({ title, onPress, disabled = false, secondary = false }) {
  return <Pressable onPress={onPress} disabled={disabled}
    style={[styles.primaryButton, secondary && styles.secondaryButton, disabled && styles.disabledButton]}>
    <Text style={[styles.primaryButtonText, secondary && styles.secondaryButtonText]}>{title}</Text>
  </Pressable>;
}

function OnboardingScreen({ navigation, route }) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const valid = firstName.trim() && lastName.trim() && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) && phone.trim().length >= 7;

  const continueToHome = async () => {
    if (!valid) return;
    const profile = { firstName: firstName.trim(), lastName: lastName.trim(), email: email.trim(), phone: phone.trim() };
    await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    navigation.replace('Home', { profile });
  };

  return <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    <ScrollView contentContainerStyle={styles.formPage} keyboardShouldPersistTaps="handled">
      <Text style={styles.brand}>LITTLE LEMON</Text>
      <Text style={styles.onboardTitle}>Let's get to know you</Text>
      <Text style={styles.bodyText}>Please enter your details to get started with Little Lemon.</Text>
      <View style={styles.formCard}>
        <Text style={styles.sectionTitle}>Personal details</Text>
        <Field label="First name" value={firstName} onChangeText={setFirstName} placeholder="Enter your first name" />
        <Field label="Last name" value={lastName} onChangeText={setLastName} placeholder="Enter your last name" />
        <Field label="Email address" value={email} onChangeText={setEmail} placeholder="name@example.com" keyboardType="email-address" />
        <Field label="Phone number" value={phone} onChangeText={setPhone} placeholder="Enter your phone number" keyboardType="phone-pad" />
        <PrimaryButton title="Next" onPress={continueToHome} disabled={!valid} />
        <Text style={styles.helperText}>All fields are required. Enter a valid email and phone number.</Text>
      </View>
    </ScrollView>
  </KeyboardAvoidingView>;
}

function MenuItem({ item }) {
  return <View style={styles.menuItem}>
    <View style={styles.menuText}>
      <Text style={styles.menuName}>{item.name}</Text>
      <Text style={styles.menuDescription} numberOfLines={2}>{item.description}</Text>
      <Text style={styles.menuPrice}>{item.price}</Text>
    </View>
    <View style={styles.foodPlaceholder}><Text style={styles.foodEmoji}>🍋</Text></View>
  </View>;
}

function HomeScreen({ navigation, route }) {
  const [profile, setProfile] = useState(route.params?.profile || null);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  useEffect(() => {
    const load = async () => {
      const stored = await AsyncStorage.getItem(PROFILE_KEY);
      if (stored) setProfile(JSON.parse(stored));
    };
    load();
  }, []);

  const filteredMenu = useMemo(() => MENU.filter(item => {
    const categoryMatch = selectedCategory === 'All' || item.category === selectedCategory;
    const searchMatch = `${item.name} ${item.description}`.toLowerCase().includes(search.toLowerCase());
    return categoryMatch && searchMatch;
  }), [selectedCategory, search]);

  return <ScrollView style={styles.screen} contentContainerStyle={styles.homeContent}>
    <View style={styles.homeHeader}>
      <View><Text style={styles.brand}>LITTLE LEMON</Text><Text style={styles.headerSub}>Chicago</Text></View>
      <Pressable style={styles.avatar} onPress={() => navigation.navigate('Profile', { profile })}>
        <Text style={styles.avatarText}>{profile?.firstName?.[0]?.toUpperCase() || 'P'}</Text>
      </Pressable>
    </View>

    <View style={styles.hero}>
      <Text style={styles.heroTitle}>Little Lemon</Text>
      <Text style={styles.heroLocation}>Chicago</Text>
      <Text style={styles.heroDescription}>We are a family-owned Mediterranean restaurant, focused on traditional recipes served with a modern twist.</Text>
      <TextInput style={styles.searchInput} value={search} onChangeText={setSearch}
        placeholder="⌕  Search menu" placeholderTextColor="#64716B" />
    </View>

    <Text style={styles.sectionTitle}>ORDER FOR DELIVERY!</Text>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryRow}>
      {CATEGORIES.map(category => <Pressable key={category} onPress={() => setSelectedCategory(category)}
        style={[styles.categoryChip, selectedCategory === category && styles.categoryChipActive]}>
        <Text style={[styles.categoryText, selectedCategory === category && styles.categoryTextActive]}>{category}</Text>
      </Pressable>)}
    </ScrollView>

    <View style={styles.menuHeader}><Text style={styles.sectionTitle}>MENU</Text><Text style={styles.itemCount}>{filteredMenu.length} items</Text></View>
    {filteredMenu.length ? filteredMenu.map(item => <MenuItem key={item.id} item={item} />) :
      <Text style={styles.emptyText}>No menu items found. Try another search or category.</Text>}
    <Text style={styles.footer}>Little Lemon • Fresh food, good mood.</Text>
  </ScrollView>;
}

function ProfileScreen({ navigation, route }) {
  const [firstName, setFirstName] = useState(route.params?.profile?.firstName || '');
  const [lastName, setLastName] = useState(route.params?.profile?.lastName || '');
  const [email, setEmail] = useState(route.params?.profile?.email || '');
  const [phone, setPhone] = useState(route.params?.profile?.phone || '');

  useEffect(() => {
    const load = async () => {
      const stored = await AsyncStorage.getItem(PROFILE_KEY);
      if (stored) {
        const p = JSON.parse(stored);
        setFirstName(p.firstName || ''); setLastName(p.lastName || '');
        setEmail(p.email || ''); setPhone(p.phone || '');
      }
    };
    load();
  }, []);

  const save = async () => {
    if (!firstName.trim() || !lastName.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()) || phone.trim().length < 7) {
      Alert.alert('Check your details', 'Please complete all fields with a valid email and phone number.');
      return;
    }
    const profile = { firstName: firstName.trim(), lastName: lastName.trim(), email: email.trim(), phone: phone.trim() };
    await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    Alert.alert('Saved', 'Your profile details have been updated.');
    navigation.setParams({ profile });
  };

  const logout = () => Alert.alert('Log out', 'Are you sure you want to clear your profile and log out?', [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Log out', style: 'destructive', onPress: async () => {
      await AsyncStorage.removeItem(PROFILE_KEY);
      navigation.reset({ index: 0, routes: [{ name: 'Onboarding' }] });
    }}
  ]);

  return <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
    <ScrollView contentContainerStyle={styles.formPage}>
      <Text style={styles.brand}>LITTLE LEMON</Text>
      <Text style={styles.onboardTitle}>Your profile</Text>
      <Text style={styles.bodyText}>Update your personal information below.</Text>
      <View style={styles.formCard}>
        <Field label="First name" value={firstName} onChangeText={setFirstName} placeholder="First name" />
        <Field label="Last name" value={lastName} onChangeText={setLastName} placeholder="Last name" />
        <Field label="Email address" value={email} onChangeText={setEmail} placeholder="Email" keyboardType="email-address" />
        <Field label="Phone number" value={phone} onChangeText={setPhone} placeholder="Phone" keyboardType="phone-pad" />
        <PrimaryButton title="Save changes" onPress={save} />
        <PrimaryButton title="Log out" onPress={logout} secondary />
      </View>
    </ScrollView>
  </KeyboardAvoidingView>;
}

function AppNavigator() {
  const [initialRoute, setInitialRoute] = useState(null);
  const [initialProfile, setInitialProfile] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(PROFILE_KEY);
        if (stored) { setInitialProfile(JSON.parse(stored)); setInitialRoute('Home'); }
        else setInitialRoute('Onboarding');
      } catch (e) { setInitialRoute('Onboarding'); }
    })();
  }, []);

  if (!initialRoute) return <View style={styles.loading}><ActivityIndicator size="large" color={COLORS.green} /></View>;

  return <NavigationContainer>
    <Stack.Navigator initialRouteName={initialRoute} screenOptions={{
      headerTintColor: COLORS.green, headerTitleStyle: { fontWeight: '700' },
      headerStyle: { backgroundColor: COLORS.cream }, contentStyle: { backgroundColor: COLORS.cream }
    }}>
      <Stack.Screen name="Onboarding" component={OnboardingScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Home" component={HomeScreen} initialParams={{ profile: initialProfile }} options={{ headerShown: false }} />
      <Stack.Screen name="Profile" component={ProfileScreen} options={{ title: 'Profile' }} />
    </Stack.Navigator>
  </NavigationContainer>;
}

export default function App() {
  return <><StatusBar style="light" /><AppNavigator /></>;
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.cream },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.cream },
  formPage: { flexGrow: 1, padding: 22, justifyContent: 'center' },
  brand: { color: COLORS.green, fontSize: 21, fontWeight: '900', letterSpacing: 2 },
  onboardTitle: { color: COLORS.dark, fontSize: 29, fontWeight: '800', marginTop: 22 },
  bodyText: { color: COLORS.muted, fontSize: 15, lineHeight: 22, marginTop: 8, marginBottom: 22 },
  formCard: { backgroundColor: COLORS.white, borderRadius: 18, padding: 20, borderWidth: 1, borderColor: COLORS.line },
  sectionTitle: { color: COLORS.dark, fontSize: 16, fontWeight: '900', letterSpacing: 1, marginBottom: 14 },
  fieldWrap: { marginBottom: 15 },
  fieldLabel: { color: COLORS.dark, fontSize: 14, fontWeight: '700', marginBottom: 7 },
  input: { backgroundColor: '#FAFBF9', borderColor: '#D9E0DB', borderWidth: 1, borderRadius: 10, paddingHorizontal: 13, paddingVertical: 13, fontSize: 15, color: COLORS.dark },
  primaryButton: { backgroundColor: COLORS.yellow, paddingVertical: 15, borderRadius: 11, alignItems: 'center', marginTop: 7 },
  primaryButtonText: { color: COLORS.dark, fontSize: 16, fontWeight: '800' },
  disabledButton: { opacity: 0.4 },
  secondaryButton: { backgroundColor: COLORS.white, borderWidth: 1, borderColor: COLORS.green, marginTop: 12 },
  secondaryButtonText: { color: COLORS.green },
  helperText: { color: COLORS.muted, fontSize: 12, textAlign: 'center', marginTop: 12 },
  homeContent: { paddingBottom: 25 },
  homeHeader: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  headerSub: { color: COLORS.muted, marginTop: 2, fontSize: 12 },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: COLORS.yellow, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: COLORS.dark, fontWeight: '900', fontSize: 18 },
  hero: { backgroundColor: COLORS.green, padding: 22, marginHorizontal: 0, paddingBottom: 20 },
  heroTitle: { color: COLORS.yellow, fontSize: 32, fontWeight: '900' },
  heroLocation: { color: COLORS.white, fontSize: 19, marginTop: 1, marginBottom: 9 },
  heroDescription: { color: COLORS.white, fontSize: 14, lineHeight: 21, maxWidth: 340, marginBottom: 17 },
  searchInput: { backgroundColor: COLORS.white, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12, fontSize: 15, color: COLORS.dark },
  categoryRow: { paddingHorizontal: 18, paddingBottom: 18, gap: 9 },
  categoryChip: { backgroundColor: '#E6EBE7', borderRadius: 18, paddingVertical: 10, paddingHorizontal: 16 },
  categoryChipActive: { backgroundColor: COLORS.green },
  categoryText: { color: COLORS.green, fontWeight: '700', fontSize: 13 },
  categoryTextActive: { color: COLORS.white },
  menuHeader: { paddingHorizontal: 20, paddingTop: 3, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  itemCount: { color: COLORS.muted, fontSize: 13, marginBottom: 14 },
  menuItem: { flexDirection: 'row', marginHorizontal: 20, paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: COLORS.line, alignItems: 'center' },
  menuText: { flex: 1, paddingRight: 12 },
  menuName: { color: COLORS.dark, fontSize: 17, fontWeight: '800' },
  menuDescription: { color: COLORS.muted, fontSize: 13, lineHeight: 18, marginTop: 5 },
  menuPrice: { color: COLORS.green, fontWeight: '800', marginTop: 7 },
  foodPlaceholder: { width: 76, height: 76, borderRadius: 12, backgroundColor: '#F3E9B8', alignItems: 'center', justifyContent: 'center' },
  foodEmoji: { fontSize: 33 },
  emptyText: { color: COLORS.muted, textAlign: 'center', padding: 25 },
  footer: { textAlign: 'center', color: COLORS.muted, fontSize: 12, marginTop: 25 },
});
